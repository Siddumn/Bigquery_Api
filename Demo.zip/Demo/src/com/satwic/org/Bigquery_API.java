package com.satwic.org;

/*
 * import java.io.File;
 
import java.io.FileInputStream;
import java.io.IOException;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.AuthCredentials;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.Dataset;
import com.google.cloud.bigquery.DatasetInfo;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.QueryRequest;
//import com.google.cloud.bigquery.Field;

import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FieldValue;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.StandardTableDefinition;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableInfo;
import com.google.cloud.bigquery.FieldValueList;
*/
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.Dataset;
import com.google.cloud.bigquery.DatasetInfo;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FieldValue;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.InsertAllRequest;
import com.google.cloud.bigquery.InsertAllResponse;
import com.google.cloud.bigquery.LegacySQLTypeName;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.QueryRequest;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.StandardTableDefinition;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableInfo;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Bigquery_API {
	
	public static void Bigquery_Delete(BigQuery bigquery)
	{
		QueryRequest queryConfig =QueryRequest.newBuilder("DELETE SatwicDataset.output_table10 where name='sid'").setUseLegacySql(false).build();
		bigquery.query(queryConfig);
		System.out.println("Successfully DELETED the record into table");
	}
	public static void Bigquery_Update(BigQuery bigquery)
	{
		QueryRequest queryConfig =QueryRequest.newBuilder("UPDATE SatwicDataset.output_table10 SET age='99' where name='sid'").setUseLegacySql(false).build();
		bigquery.query(queryConfig);
		System.out.println("Successfully Updated the record into table");
	}
	
	public static void Bigquery_Insert(BigQuery bigquery)
	{
		QueryRequest queryConfig =QueryRequest.newBuilder("INSERT SatwicDataset.output_table10 (name,age) values('Thowin','26')").setUseLegacySql(false).build();
		bigquery.query(queryConfig);
		System.out.println("Successfully inserted record into table");
	}
	
	public static void Bigquery_Read(BigQuery bigquery)
	{
		QueryRequest queryConfig =QueryRequest.newBuilder("SELECT name,age FROM SatwicDataset.output_table10").build();
		
    	System.out.println("Table rows:");
    	bigquery.query(queryConfig);
    	System.out.println("NAME\t"+"AGE");
        for(List<FieldValue> row :bigquery.query(queryConfig).getResult().getValues())
        {
    	  
          System.out.println(row.get(0).getValue()+"\t"+row.get(1).getValue());

        }
		
	}

	public static void main(String[] args) throws IOException {
		
		BigQuery bigquery = BigQueryOptions.getDefaultInstance().getService();
		
		//Bigquery_Read(bigquery);
		//Bigquery_Insert(bigquery);
		//Bigquery_Update(bigquery);
		//Bigquery_Delete(bigquery);
	
	}
	

}
